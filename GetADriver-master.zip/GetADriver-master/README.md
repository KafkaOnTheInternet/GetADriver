# GetADriver
GetADriver is a cheaper alternative to a taxi service, for anyone who wants someone to drive their own car for them as opposed to having to drive it themselves
